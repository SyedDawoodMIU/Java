
public class Button {

    public Button(String string) {
    }

    public void addActionListener(Object object) {
    }


}
