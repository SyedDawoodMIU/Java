
public interface ICommand {
    public void execute();

}
