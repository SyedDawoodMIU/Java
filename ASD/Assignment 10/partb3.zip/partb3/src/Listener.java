
public interface Listener {
    void onSpeedChanged(int newSpeed);
}