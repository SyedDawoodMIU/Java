
public class WindowFrame implements IFrame {

    public void print(int newSpeed) {
    }

}


interface IFrame
{
    void print(int newSpeed);
}
