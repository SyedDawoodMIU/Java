package framework;

public interface Listener {
    void onSpeedChanged(int newSpeed);
}
