package framework;

public interface Car {
    int speed();
    void increaseSpeed();
    void decreaseSpeed();
    void logSpeed();
    void jump();
}