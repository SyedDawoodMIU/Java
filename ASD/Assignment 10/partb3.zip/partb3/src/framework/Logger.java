package framework;

public class Logger {
    public static void log(int newSpeed) {
        System.out.println("The car's speed is now " + newSpeed);
    }
}