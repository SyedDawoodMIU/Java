package framework;

public class DAO {
    public int getSpeed() {
        return 0;
    }

    public void setSpeed(int newSpeed) {
    }
}