package counter;

interface Observer {
    void update(int count);
}