package shopping;

public class CreditCardPayment implements Payment {
    @Override
    public void makePayment() {
        
    }
}