package shopping;

public interface Payment {
    void makePayment();
}