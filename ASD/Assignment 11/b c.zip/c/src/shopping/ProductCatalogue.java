
package shopping;

public interface ProductCatalogue {

}



