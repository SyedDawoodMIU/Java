package dao;

import shopping.ProductCatalogue;

public class ProductCatalogueDAO {
    public ProductCatalogue getById(String catalogueId) {
        
        return null;
    }

    public void save(ProductCatalogue catalogue) {
        
    }

    public void update(ProductCatalogue catalogue) {
        
    }

    public void delete(ProductCatalogue catalogue) {
        
    }
}