package dao;

import shopping.Order;

public class OrderDAO {
    public Order getById(String orderId) {
        
        return null;
    }

    public void save(Order order) {
        
    }

    public void update(Order order) {
        
    }

    public void delete(Order order) {
        
    }
}