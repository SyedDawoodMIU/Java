package dao;

import shopping.Payment;

public class PaymentDAO {
    public Payment getById(String paymentId) {
        
        return null;
    }

    public void save(Payment payment) {
        
    }

    public void update(Payment payment) {
        
    }

    public void delete(Payment payment) {
        
    }
}