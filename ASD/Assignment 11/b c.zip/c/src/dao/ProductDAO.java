
package dao;

import shopping.Product;

public class ProductDAO {
    public Product getById(String productId) {
        
        return null;
    }

    public void save(Product product) {
        
    }

    public void update(Product product) {
        
    }

    public void delete(Product product) {
        
    }
}
