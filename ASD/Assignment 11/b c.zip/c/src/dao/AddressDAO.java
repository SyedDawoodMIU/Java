package dao;

import shopping.Address;

public class AddressDAO {
    public Address getById(String addressId) {
        
        return null;
    }

    public void save(Address address) {
        
    }

    public void update(Address address) {
        
    }

    public void delete(Address address) {
        
    }
}