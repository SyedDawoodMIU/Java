package dao;

import shopping.ShoppingCart;

public class ShoppingCartDAO {
    public ShoppingCart getById(String cartId) {
        
        return null;
    }

    public void save(ShoppingCart cart) {
        
    }

    public void update(ShoppingCart cart) {
        
    }

    public void delete(ShoppingCart cart) {
        
    }
}