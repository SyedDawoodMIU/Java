package dao;

import shopping.CustomerInfo;

public class CustomerInfoDAO {
    public CustomerInfo getById(String customerId) {

        return null;
    }

    public void save(CustomerInfo customerInfo) {

    }

    public void update(CustomerInfo customerInfo) {

    }

    public void delete(CustomerInfo customerInfo) {

    }
}