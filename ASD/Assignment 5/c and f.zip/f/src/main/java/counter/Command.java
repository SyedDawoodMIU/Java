package counter;

public interface Command {
    void execute();
    void undo();
    void redo();
}