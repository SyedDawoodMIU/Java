package com.webshop.assignment.shopping;

public interface Payment {
    void makePayment();
}