package com.webshop.assignment.shopping;

public class CreditCardPayment implements Payment {
    @Override
    public void makePayment() {
        
    }
}