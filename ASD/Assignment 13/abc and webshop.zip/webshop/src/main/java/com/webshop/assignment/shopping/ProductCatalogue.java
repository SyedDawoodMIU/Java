
package com.webshop.assignment.shopping;

public interface ProductCatalogue {

}



