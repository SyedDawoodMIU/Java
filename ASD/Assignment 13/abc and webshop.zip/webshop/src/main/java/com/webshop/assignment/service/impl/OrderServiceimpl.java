package com.webshop.assignment.service.impl;
import com.webshop.assignment.service.OrderService;
import com.webshop.assignment.shopping.Address;
import com.webshop.assignment.shopping.CustomerInfo;
import com.webshop.assignment.shopping.Order;
import com.webshop.assignment.shopping.Payment;

public class OrderServiceimpl implements OrderService {

    @Override
    public Order getOrderById(String orderId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getOrderById'");
    }

    @Override
    public void saveOrder(Order order) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'saveOrder'");
    }

    @Override
    public void updateOrder(Order order) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateOrder'");
    }

    @Override
    public void deleteOrder(Order order) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteOrder'");
    }

    @Override
    public void addPaymentToOrder(String orderId, Payment payment) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addPaymentToOrder'");
    }

    @Override
    public void addCustomerInfoToOrder(String orderId, CustomerInfo customerInfo) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addCustomerInfoToOrder'");
    }

    @Override
    public void addShippingAddressToOrder(String orderId, Address address) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addShippingAddressToOrder'");
    }

    @Override
    public void addBillingAddressToOrder(String orderId, Address address) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addBillingAddressToOrder'");
    }

    @Override
    public void placeOrder(String orderId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'placeOrder'");
    }

}